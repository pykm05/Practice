package interfaces;

public interface ShapeRevealer {
    void sayName();
}
