package polymorphism;
public class Car extends Vehicle{
    @Override
    public void startEngine() {
        System.out.println("Car goes skrrt");
    }
}
