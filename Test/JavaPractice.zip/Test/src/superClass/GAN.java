package superClass;

public class GAN extends Cube{
    private final int cornerCut = 55;
    public GAN() {
        System.out.println("A GAN cube.");
    }

    public int getCornerCut() {
        return cornerCut;
    }
}
