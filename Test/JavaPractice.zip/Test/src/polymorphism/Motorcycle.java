package polymorphism;

public class Motorcycle extends Vehicle{
    @Override
    public void startEngine() {
        System.out.println("Motorcycle goes vroom");
    }
}
